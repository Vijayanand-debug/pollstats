from django.apps import AppConfig


class PollstatsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pollstats'
